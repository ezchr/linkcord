// SPDX-License-Identifier: Unlicense OR MIT

//go:build darwin && !ios

package explorer

/*
#cgo CFLAGS: -Werror -xobjective-c -fmodules -fobjc-arc

#import <AppKit/AppKit.h>

// Defined on explorer_macos.m file.
extern void exportFile(CFTypeRef viewRef, char * name, int32_t id);
extern void importFile(CFTypeRef viewRef, char * ext, int32_t id);
extern void chooseFolder(CFTypeRef viewRef, int32_t id);
*/
import "C"
import (
	"io"
	"net/url"
	"os"
	"strings"

	"gioui.org/app"
	"gioui.org/io/event"
)

type explorer struct {
	window *app.Window
	view   C.CFTypeRef
	result chan result
}

func newExplorer(w *app.Window) *explorer {
	return &explorer{window: w, result: make(chan result)}
}

func (e *Explorer) listenEvents(evt event.Event) {
	switch evt := evt.(type) {
	case app.AppKitViewEvent:
		e.view = C.CFTypeRef(evt.View)
	}
}

func (e *Explorer) exportFile(name string) (io.WriteCloser, error) {
	cname := C.CString(name)
	e.window.Run(func() { C.exportFile(e.view, cname, C.int32_t(e.id)) })

	resp := <-e.result
	if resp.error != nil {
		return nil, resp.error
	}
	return resp.file.(io.WriteCloser), resp.error

}

func (e *Explorer) importFile(extensions ...string) (io.ReadCloser, error) {
	for i, ext := range extensions {
		extensions[i] = strings.TrimPrefix(ext, ".")
	}

	cextensions := C.CString(strings.Join(extensions, ","))
	e.window.Run(func() { C.importFile(e.view, cextensions, C.int32_t(e.id)) })

	resp := <-e.result
	if resp.error != nil {
		return nil, resp.error
	}
	return resp.file.(io.ReadCloser), resp.error
}

func (e *Explorer) readFile(uri string) (io.ReadCloser, error) {
	return os.Open(uri)
}

func (e *Explorer) importFiles(_ ...string) ([]io.ReadCloser, error) {
	return nil, ErrNotAvailable
}

func (e *Explorer) chooseFolder() (string, error) {
	e.window.Run(func() { C.chooseFolder(e.view, C.int32_t(e.id)) })

	resp := <-e.result
	if resp.error != nil {
		return "", resp.error
	}
	path, ok := resp.file.(string)
	if !ok {
		return "", ErrNotAvailable
	}
	return path, nil
}

//export importCallback
func importCallback(u *C.char, id int32) {
	if v, ok := active.Load(id); ok {
		v.(*explorer).result <- newOSFile(u, os.Open)
	}
}

//export exportCallback
func exportCallback(u *C.char, id int32) {
	if v, ok := active.Load(id); ok {
		v.(*explorer).result <- newOSFile(u, os.Create)
	}
}

//export folderCallback
func folderCallback(u *C.char, id int32) {
	if v, ok := active.Load(id); ok {
		path, err := selectedPath(u)
		v.(*explorer).result <- result{file: path, error: err}
	}
}

func newOSFile(u *C.char, action func(s string) (*os.File, error)) result {
	path, err := selectedPath(u)
	if err != nil {
		return result{error: err, file: nil}
	}

	f, err := action(path)
	return result{error: err, file: f}
}

func selectedPath(u *C.char) (string, error) {
	name := C.GoString(u)
	if name == "" {
		return "", ErrUserDecline
	}

	uri, err := url.Parse(name)
	if err != nil {
		return "", err
	}

	return url.PathUnescape(uri.Path)
}
