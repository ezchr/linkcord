module gioui.org/x

go 1.24.0

toolchain go1.24.3

require (
	gioui.org v0.10.3
	git.sr.ht/~jackmordaunt/go-toast v1.0.0
	git.wow.st/gmp/jni v0.0.0-20210610011705-34026c7e22d0
	github.com/andybalholm/stroke v0.0.0-20251027184313-5126dd7227a1
	github.com/esiqveland/notify v0.11.0
	github.com/go-ole/go-ole v1.2.6
	github.com/godbus/dbus/v5 v5.2.2
	github.com/yuin/goldmark v1.4.13
	golang.org/x/exp v0.0.0-20250408133849-7e4ce0ab07d0
	golang.org/x/exp/shiny v0.0.0-20250408133849-7e4ce0ab07d0
	golang.org/x/image v0.26.0
	golang.org/x/sys v0.39.0
	golang.org/x/text v0.32.0
)

require (
	gioui.org/shader v1.0.9 // indirect
	github.com/go-text/typesetting v0.3.5 // indirect
	golang.org/x/net v0.48.0 // indirect
)
