package http

import (
	"uuid"

	"github.com/ayn2op/arikawa/v3/discord"
	"github.com/ayn2op/arikawa/v3/gateway"
	"github.com/ayn2op/discordo/internal/tls"
)

//go:generate go run generator.go

const (
	osName    = "Windows"
	osVersion = "10"
	locale    = discord.EnglishUS
)

func BrowserUserAgent() string {
	return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " + tls.BrowserName() + "/" + tls.BrowserVersion() + " Safari/537.36"
}

func browserBrands() string {
	version := tls.BrowserMajorVersion()
	return `"Chromium";v="` + version + `", "Not-A.Brand";v="24", "Google ` + tls.BrowserName() + `";v="` + version + `"`
}

func commonProperties() gateway.IdentifyProperties {
	return gateway.IdentifyProperties{
		gateway.IdentifyDevice: "",

		gateway.IdentifyOS: osName,
		"os_version":       osVersion,

		gateway.IdentifyBrowser: tls.BrowserName(),
		"browser_version":       tls.BrowserVersion(),
		"browser_user_agent":    BrowserUserAgent(),

		"client_build_number": ClientBuildNumber,
		"client_event_source": nil,
		"client_launch_id":    uuid.NewV4().String(),

		"system_locale":   locale,
		"release_channel": "stable",
		"has_client_mods": false,

		"referrer":                 "",
		"referrer_current":         "",
		"referring_domain":         "",
		"referring_domain_current": "",
	}
}

func IdentifyProperties() gateway.IdentifyProperties {
	props := commonProperties()
	props["is_fast_connect"] = true
	return props
}

func xSuperProperties() gateway.IdentifyProperties {
	props := commonProperties()
	props["client_app_state"] = "focused"
	props["client_heartbeat_session_id"] = uuid.NewV4().String()
	props["launch_signature"] = generateLaunchSignature()
	return props
}

func generateLaunchSignature() string {
	// Discord uses specific UUID bits to detect client modifications.
	// This mask clears detection bits to avoid identification.
	// Reference: https://docs.discord.food/reference#launch-signature
	//
	// Required version and variant bits for UUIDv4 validity are set by uuid.NewV4.
	// Reference: https://pkg.go.dev/uuid#NewV4
	mask := [16]byte{
		0b11111111, 0b01111111, 0b11101111, 0b11101111,
		0b11110111, 0b11101111, 0b11110111, 0b11111111,
		0b11011111, 0b01111110, 0b11111111, 0b10111111,
		0b11111110, 0b11111111, 0b11110111, 0b11111111,
	}
	id := uuid.NewV4()
	for i := range mask {
		id[i] &= mask[i]
	}
	return id.String()
}
