module github.com/ayn2op/discordo

go 1.27.0

// replace github.com/ayn2op/tview => ../tview

// replace (
// 	github.com/ayn2op/arikawa/v3 => ../arikawa
// 	github.com/ayn2op/ningen/v3 => ../ningen
// )

require (
	gioui.org v0.10.3
	gioui.org/x v0.10.3
	github.com/BurntSushi/toml v1.6.0
	github.com/alecthomas/chroma/v2 v2.27.0
	github.com/andybalholm/brotli v1.2.6
	github.com/ayn2op/arikawa/v3 v3.0.0-20261012034659-5b006907b2de
	github.com/ayn2op/ningen/v3 v3.0.1-0.20260929010920-29794d5fa70e
	github.com/ayn2op/tview v0.0.0-20261012034741-d8b2704e2b8e
	github.com/bogdanfinn/fhttp v0.6.9
	github.com/bogdanfinn/tls-client v1.16.0
	github.com/gdamore/tcell/v3 v3.6.0
	github.com/gen2brain/malgo v0.11.26
	github.com/gorilla/websocket v1.5.3
	github.com/klauspost/compress v1.20.1
	github.com/mattn/go-shellwords v1.0.16
	github.com/ncruces/zenity v0.10.15
	github.com/rivo/uniseg v0.4.7
	github.com/sahilm/fuzzy v0.1.3
	github.com/skip2/go-qrcode v0.0.0-20200617195104-da1b6568686e
	github.com/skratchdot/open-golang v0.0.0-20200116055534-eef842397966
	github.com/thomas-vilte/dave-go v0.5.1
	github.com/tphakala/go-opus v1.1.0
	github.com/yuin/goldmark v1.8.6
	github.com/zalando/go-keyring v0.2.8
	golang.design/x/clipboard v0.11.0
	golang.org/x/exp/shiny v0.0.0-20261011100332-faecfb24eb49
	golang.org/x/image v0.47.0
)

require (
	gioui.org/shader v1.0.9 // indirect
	github.com/akavel/rsrc v0.10.2 // indirect
	github.com/bdandy/go-errors v1.2.2 // indirect
	github.com/bdandy/go-socks4 v1.2.3 // indirect
	github.com/bogdanfinn/quic-go-utls v1.0.10-utls // indirect
	github.com/bogdanfinn/utls v1.7.8-barnius // indirect
	github.com/bogdanfinn/websocket v1.5.6-barnius // indirect
	github.com/clipperhouse/displaywidth v0.11.0 // indirect
	github.com/clipperhouse/uax29/v2 v2.7.0 // indirect
	github.com/cloudflare/circl v1.6.5 // indirect
	github.com/danieljoos/wincred v1.2.3 // indirect
	github.com/dchest/jsmin v1.0.0 // indirect
	github.com/disgoorg/godave v0.3.0 // indirect
	github.com/dlclark/regexp2/v2 v2.8.4 // indirect
	github.com/ebitengine/purego v0.11.1 // indirect
	github.com/gdamore/encoding v1.0.1 // indirect
	github.com/go-text/typesetting v0.3.5 // indirect
	github.com/godbus/dbus/v5 v5.2.3 // indirect
	github.com/gorilla/schema v1.4.1 // indirect
	github.com/josephspurrier/goversioninfo v1.7.0 // indirect
	github.com/lucasb-eyer/go-colorful v1.4.1 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	github.com/randall77/makefat v0.0.0-20260406194835-1b91746796b7 // indirect
	github.com/tam7t/hpkp v0.0.0-20160821193359-2b70b4024ed5 // indirect
	github.com/thomas-vilte/mls-go v1.6.0 // indirect
	github.com/tphakala/simd v1.11.0 // indirect
	github.com/twmb/murmur3 v1.2.1 // indirect
	go4.org v0.0.0-20260112195520-a5071408f32f // indirect
	golang.design/x/x11 v0.2.0 // indirect
	golang.org/x/crypto v0.58.0 // indirect
	golang.org/x/exp v0.0.0-20250408133849-7e4ce0ab07d0 // indirect
	golang.org/x/mobile v0.0.0-20261011034528-197770444867 // indirect
	golang.org/x/net v0.61.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
	golang.org/x/term v0.47.0 // indirect
	golang.org/x/text v0.43.0 // indirect
	golang.org/x/time v0.16.0 // indirect
)

replace gioui.org => ./third_party/gioui

replace gioui.org/x => ./third_party/giox
